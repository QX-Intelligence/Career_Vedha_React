# Page snapshot

```yaml
- generic [ref=e4]:
  - banner [ref=e5]:
    - generic [ref=e6]:
      - generic [ref=e8]: 
      - generic [ref=e9]: Exam Instructions
  - generic [ref=e11]:
    - generic [ref=e13]: 
    - heading "Ready to Begin?" [level=2] [ref=e14]
    - paragraph [ref=e15]: You are about to start the assessment. The timer will begin as soon as you click Start.
    - generic [ref=e16]:
      - generic [ref=e17]:
        - generic [ref=e18]: "15"
        - generic [ref=e19]: Questions
      - generic [ref=e20]:
        - generic [ref=e21]: "30"
        - generic [ref=e22]: Minutes
    - generic [ref=e23]:
      - button "Go Back" [ref=e24] [cursor=pointer]
      - button "Start Exam " [ref=e25] [cursor=pointer]:
        - text: Start Exam
        - generic [ref=e26]: 
```