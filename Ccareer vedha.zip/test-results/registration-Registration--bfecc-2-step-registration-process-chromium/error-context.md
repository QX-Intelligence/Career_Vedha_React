# Page snapshot

```yaml
- generic [ref=e5]:
  - generic [ref=e7]:
    - generic [ref=e9]: 
    - heading "Admin Portal" [level=1] [ref=e10]
    - paragraph [ref=e11]: Secure Access for Career Vedha
    - generic [ref=e12]:
      - generic [ref=e13]:
        - generic [ref=e14]: 
        - generic [ref=e15]: User Management
      - generic [ref=e16]:
        - generic [ref=e17]: 
        - generic [ref=e18]: Analytics & Reports
      - generic [ref=e19]:
        - generic [ref=e20]: 
        - generic [ref=e21]: Secure Platform
  - generic [ref=e24]:
    - generic [ref=e25]:
      - heading "Admin Login" [level=2] [ref=e26]
      - paragraph [ref=e27]: Enter your authorized email
    - generic [ref=e28]:
      - generic [ref=e29]:
        - generic [ref=e30]: Email Address
        - generic [ref=e31]:
          - generic [ref=e32]: 
          - textbox "admin@careervedha.com" [active] [ref=e33]
      - button "Send Verification Code" [ref=e34] [cursor=pointer]
      - paragraph [ref=e36]:
        - text: New Admin?
        - link "Request Access" [ref=e37] [cursor=pointer]:
          - /url: /admin-register
```